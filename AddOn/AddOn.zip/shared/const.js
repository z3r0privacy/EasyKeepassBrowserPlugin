const stateLocked = "stateLocked";
const stateUnlockedOk = "stateUnlockedOk";
const stateUnlockedErr = "stateUnlockedErr";
const stateSetup = "stateSetup";

const actionGetState = "msgActionGetState";
const actionTryUnlock = "msgActionTryUnlock";
const actionGetKey = "msgActionGetKey";
const actionSetup = "msgActionSetup";